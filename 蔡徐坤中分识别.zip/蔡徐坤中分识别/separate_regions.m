function separate_regions(Label, I, outputFolder)
num = max(Label(:));        % 获取连通区域的数量

% 遍历每个区域
for regionIdx = 1:num
        % 创建掩膜，仅保留当前区域
    regionMask = (Label == regionIdx);

        % 提取该区域的边界框
    props = regionprops(regionMask, 'BoundingBox');
    bbox = round(props.BoundingBox);
    x1 = bbox(1); y1 = bbox(2); w = bbox(3); h = bbox(4);

        % 裁剪出边界框内的区域
    croppedMask = regionMask(y1:y1+h-1, x1:x1+w-1);
    croppedRGB = I(y1:y1+h-1, x1:x1+w-1, :) .* uint8(cat(3, croppedMask, croppedMask, croppedMask));

        % 将裁剪区域居中到正方形画布
    sideLength = max(w, h); % 正方形的边长
    squareCanvas = zeros(sideLength, sideLength, 3, 'uint8');
    offsetX = floor((sideLength - w) / 2);
    offsetY = floor((sideLength - h) / 2);
    squareCanvas(offsetY+1:offsetY+h, offsetX+1:offsetX+w, :) = croppedRGB;

        % 保存正方形区域图片
    filename = fullfile(outputFolder, sprintf('Region_%d.png', regionIdx));
    imwrite(squareCanvas, filename);
    filenames{regionIdx} = filename;
        % 显示分割结果
    figure;
    imshow(croppedRGB);
    title(['切分图 ', num2str(regionIdx)]);
end
end