% 输入：标记矩阵 Label，原始二值图像 BW2
% 输出：每个区域是否为中分的判断结果 (1为中分，0为非中分)
function results = identify_middle_parts(Label, BW2)
    num = max(Label(:));      % 获取区域总数
    results = zeros(1, num);  % 预分配结果数组

    for regionIdx = 1:num
        % 为当前区域生成掩膜
        regionMask = (Label == regionIdx);

        % 提取该区域的子图像
        regionBW = BW2 .* regionMask;

        % 使用测角度函数判断
        results(regionIdx) = angle_Identification(regionBW);

        % 显示区域和判断结果
        figure;
        imshow(regionBW);
        title(['Region ', num2str(regionIdx), ' Result: ', num2str(results(regionIdx))]);
    end
end
