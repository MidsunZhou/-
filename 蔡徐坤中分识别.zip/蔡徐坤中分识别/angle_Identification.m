function results = angle_Identification(outputFolder)

imageFiles = dir(fullfile(outputFolder, '*.png')); % 假设图片为PNG格式
numImages = length(imageFiles); % 图片数量
results = zeros(numImages, 1); % 初始化结果矩阵

% 遍历每张图片
for i = 1:numImages
    % 读取当前图片
    imagePath = fullfile(outputFolder, imageFiles(i).name);    
    img = imread(imagePath); % 假设输入图像已裁剪且为灰度图
    if size(img, 3) == 3
    img = rgb2gray(img);
    end
    disp(['正在处理图片: ', imageFiles(i).name]);
    % figure;
    % imshow(img);
    % title('查看读取的原始图像');

    % 提取发型顶部区域
    [row, ~] = size(img);
    topRegion = img(1:floor(row/3), :); % 只取上三分之一
    figure, imshow(topRegion), title('头发分开角度');
    hold on;
 
    % 找到发际线的分开点
    [y, x] = find(topRegion); % 获取边缘点坐标
    if isempty(y) || isempty(x)
        disp('未检测到发际线边缘，跳过该图片。');
        results(i) = 0; % 无法检测时默认非中分
        continue;
    end
    splitPointX = round(mean(x)); % 找到大致的分开点（头顶中间）

   % 分开左右两部分
    leftPoints = [x(x < splitPointX), y(x < splitPointX)];
    rightPoints = [x(x > splitPointX), y(x > splitPointX)];

    % 拟合左右两侧的线条
    if size(leftPoints, 1) > 2 && size(rightPoints, 1) > 2
    % 左侧拟合直线
        leftFit = polyfit(leftPoints(:, 2), leftPoints(:, 1), 1); 
        leftLineY = min(leftPoints(:, 2)):max(leftPoints(:, 2)); % 左侧Y范围
        leftLineX = polyval(leftFit, leftLineY); % 左侧X坐标
        plot(leftLineX, leftLineY, 'r', 'LineWidth', 2); % 绘制左侧拟合直线

    % 右侧拟合直线
        rightFit = polyfit(rightPoints(:, 2), rightPoints(:, 1), 1); 
        rightLineY = min(rightPoints(:, 2)):max(rightPoints(:, 2)); % 右侧Y范围
        rightLineX = polyval(rightFit, rightLineY); % 右侧X坐标
        plot(rightLineX, rightLineY, 'g', 'LineWidth', 2); % 绘制右侧拟合直线
    else
        disp(['图片 ', imageFiles(i).name, ' 边缘点不足，无法拟合直线']);
        results(i) = 0; % 无法检测时默认非中分
    end
        % 计算分开角度
        leftSlope = leftFit(1); % 左侧斜率
        rightSlope = rightFit(1); % 右侧斜率
        angle = 180 - (atan(abs((rightSlope - leftSlope) / (1 + leftSlope * rightSlope))) * (180 / pi));
       
        % 判断是否为中分
        if angle >= 120 
            results(i) = 1; % 中分
            disp(['图片 ', imageFiles(i).name, ' 检测到中分，分开角度为：', num2str(angle), '度']);
        else
            results(i) = 0; % 非中分
            disp(['图片 ', imageFiles(i).name, ' 不是中分，分开角度为：', num2str(angle), '度']);
        end
   
end


